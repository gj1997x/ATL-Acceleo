// Start of user code imports
// End of user code

public class Book {

        extends LibraryItem

        private String isbn; 
        private String publisher; 
        private Integer pageCount; 

        public String getIsbn() {
            return this.isbn;
        }

        public void setIsbn(String isbn) {
             this.isbn = isbn;
        }
        public String getPublisher() {
            return this.publisher;
        }

        public void setPublisher(String publisher) {
             this.publisher = publisher;
        }
        public Integer getPageCount() {
            return this.pageCount;
        }

        public void setPageCount(Integer pageCount) {
             this.pageCount = pageCount;
        }

        public String description() {
			// Start of user code description
            // TODO implement   
			// End of user code
        }

} 
