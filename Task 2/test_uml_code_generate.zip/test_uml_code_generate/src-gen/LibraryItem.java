// Start of user code imports
// End of user code

public class LibraryItem 

{

        private String title; 
        private String libraryId; 
        private Genre genre; 

        public String getTitle() {
            return this.title;
        }

        public void setTitle(String title) {
             this.title = title;
        }
        public String getLibraryId() {
            return this.libraryId;
        }

        public void setLibraryId(String libraryId) {
             this.libraryId = libraryId;
        }
        public Genre getGenre() {
            return this.genre;
        }

        public void setGenre(Genre genre) {
             this.genre = genre;
        }


} 
