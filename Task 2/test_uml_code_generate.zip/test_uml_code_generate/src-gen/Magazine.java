// Start of user code imports
// End of user code

public class Magazine 

        extends LibraryItem
{



        public String issue() {
			// Start of user code issue
            // TODO implement   
			// End of user code
        }

} 
