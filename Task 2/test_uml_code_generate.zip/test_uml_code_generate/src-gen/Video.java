// Start of user code imports
// End of user code

public class Video {

        extends LibraryItem

        private Integer runtime; 
        private String director; 

        public Integer getRuntime() {
            return this.runtime;
        }

        public void setRuntime(Integer runtime) {
             this.runtime = runtime;
        }
        public String getDirector() {
            return this.director;
        }

        public void setDirector(String director) {
             this.director = director;
        }

        public String duration() {
			// Start of user code duration
            // TODO implement   
			// End of user code
        }

} 
